./objects/gpio.o: gpio.c C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  ..\MultiPurposeConsoleImplementation\tm4c123gh6pm.h \
  ..\MultiPurposeConsoleImplementation\gpio.h \
  ..\MultiPurposeConsoleImplementation\app.h
