./objects/uart.o: uart.c C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  ..\MultiPurposeConsoleImplementation\tm4c123gh6pm.h \
  ..\MultiPurposeConsoleImplementation\uart.h
