./objects/app.o: app.c C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  ..\MultiPurposeConsoleImplementation\app.h \
  ..\MultiPurposeConsoleImplementation\uart.h \
  ..\MultiPurposeConsoleImplementation\gpio.h
