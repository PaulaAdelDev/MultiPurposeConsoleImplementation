./objects/main.o: main.c C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  ..\MultiPurposeConsoleImplementation\tm4c123gh6pm.h \
  ..\MultiPurposeConsoleImplementation\app.h \
  ..\MultiPurposeConsoleImplementation\gpio.h \
  ..\MultiPurposeConsoleImplementation\uart.h \
  ..\MultiPurposeConsoleImplementation\timers.h \
  ..\MultiPurposeConsoleImplementation\adc.h
